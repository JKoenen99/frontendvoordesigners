var filmcard = document.querySelectorAll('article');

filmcard.onclick = function() {
	filmcard.classList.toggle('big');
	console.log("werk eens joh kutknop");
}


// var filmcard = document.querySelectorAll('article');

// function big() {
//   filmcard.classList.toggle('big');
// }

// filmcard.addEventListener('click', big);

